#pragma once

#ifndef BIRD_H
#define BIRD_H

#include <string>
#include "AbstractAnimal.h"
#include "Date.h"

class Bird : public AbstractAnimal {
public:
    Bird() = delete;
    Bird(std::string nickName, Date dateOfBirth, double winspan = 0.5);
    virtual ~Bird() = default;

    double getWingspan() const;
    std::string toString() const noexcept override;
protected:
    double wingspan_; // ������ �������
};
#endif // BIRD_H

