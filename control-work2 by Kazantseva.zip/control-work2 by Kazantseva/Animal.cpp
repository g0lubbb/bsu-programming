#define _SILENCE_STDEXT_ARR_ITERS_DEPRECATION_WARNING
#define _CRT_SECURE_NO_WARNINGS
#include "Animal.h"

#include "Date.h"
#include "spdlog/spdlog.h"

#include <sstream>
#include <string>

Animal::Animal(std::string nickName, Date dateOfBirth)
        : dateOfBirth_(dateOfBirth), log_(spdlog::get("animalLog")) {
    log_->trace("Aminal Ctor");

    nickName_ = new char[nickName.size() + 1];
    char* cstr = new char[nickName.length() + 1];
    strcpy(cstr, nickName.c_str());
}

Animal::~Animal() {
    log_->debug("Aminal Dtor");
    delete[] nickName_;
}

Animal::Animal(const Animal& animal)
        : dateOfBirth_(animal.dateOfBirth_), log_(spdlog::get("animalLog")) {
    if (this == &animal) {
        *this = animal;
    }
}

Animal& Animal::operator=(const Animal& animal) {
    delete[] nickName_;
    nickName_ = new char[strlen(animal.nickName_) + 1];
    strcpy(nickName_, animal.nickName_);
    dateOfBirth_ = animal.dateOfBirth_;

    return *this;
}

Animal::Animal(Animal&& animal)
        : dateOfBirth_(animal.dateOfBirth_), log_(spdlog::get("animalLog")) {
    *this = animal;
}

Animal& Animal::operator=(Animal&& animal) {
    std::swap(nickName_, animal.nickName_);
    std::swap(dateOfBirth_, animal.dateOfBirth_);

    return *this;
}

std::string Animal::name() const noexcept {
    std::string result(nickName_);
    return result;
}

Date Animal::dateOfBirth() const noexcept {
    return dateOfBirth_;
}








