#include "AbstractAnimal.h"

#include <sstream>
#include <string>

class МicrochippedAnimal : public AbstractAnimal {
private:
    std::string chip_;

public:
    bool checkChip(const std::string& chip) {
        return chip_ == chip;
    }

    std::string description() const {
        std::string nickName(nickName_);
        std::ostringstream out("");
        out << "Name: " << nickName << "; DateOfBirth: " << dateOfBirth_ << "; Age: " << age()
            << "; Chip: " << chip_;
        return nickName;
    }
};