#define _SILENCE_STDEXT_ARR_ITERS_DEPRECATION_WARNING
#define _CRT_SECURE_NO_WARNINGS
#include "AbstractAnimal.h"

#include "Date.h"
#include "spdlog/spdlog.h"

#include <sstream>
#include <string>
#include <vector>

AbstractAnimal::AbstractAnimal(std::string nickName, Date dateOfBirth)
        : dateOfBirth_(dateOfBirth), log_(spdlog::get("animalLog")) {
    log_->trace("Aminal Ctor");

    nickName_ = new char[nickName.size() + 1];
    strcpy(nickName_, nickName.c_str());
}

AbstractAnimal::~AbstractAnimal() {
    log_->debug("Aminal Dtor");
    delete[] nickName_;
}

AbstractAnimal::AbstractAnimal(const AbstractAnimal& animal)
        : dateOfBirth_(animal.dateOfBirth_), log_(spdlog::get("animalLog")) {
    if (this == &animal) {
        *this = animal;
    }
}

AbstractAnimal& AbstractAnimal::operator=(const AbstractAnimal& animal) {
    delete[] nickName_;
    nickName_ = new char[strlen(animal.nickName_) + 1];
    strcpy(nickName_, animal.nickName_);
    dateOfBirth_ = animal.dateOfBirth_;

    return *this;
}

AbstractAnimal::AbstractAnimal(AbstractAnimal&& animal)
        : dateOfBirth_(animal.dateOfBirth_), log_(spdlog::get("animalLog")) {
    *this = animal;
}

AbstractAnimal& AbstractAnimal::operator=(AbstractAnimal&& animal) {
    std::swap(nickName_, animal.nickName_);
    std::swap(dateOfBirth_, animal.dateOfBirth_);

    return *this;
}

std::string AbstractAnimal::name() const noexcept {
    std::string result(nickName_);
    return result;
}

Date AbstractAnimal::dateOfBirth() const noexcept {
    return dateOfBirth_;
}

int AbstractAnimal::age() const noexcept {
    return dateOfBirth_.age();
}

int AbstractAnimal::age(const Date& date) const noexcept {
    return dateOfBirth_.age(date);
}

std::string AbstractAnimal::toString() const noexcept {
    std::ostringstream out("");
    out << name() << " " << dateOfBirth_;

    return out.str();
}
