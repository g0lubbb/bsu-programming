#define _CRT_SECURE_NO_WARNINGS
#define _SILENCE_STDEXT_ARR_ITERS_DEPRECATION_WARNING
#include "Date.h"

#include "lib/spdlog/include/spdlog/spdlog.h"

#include <ctime>
#include <exception>
#include <memory>
#include <sstream>


int Date::age() const noexcept {
    std::time_t now = std::time(nullptr);
    std::tm* local_time = std::localtime(&now);
    Date today(local_time->tm_year + 1900, local_time->tm_mon + 1, local_time->tm_mday);

    return this->age(today);
}

// TODO TO IMPLEMENT
int Date::age(const Date& date) const noexcept {
    int age = 0;
    // Вычисляем разницу в годах между текущей датой и переданной датой
    age = year_ - date.year_;
    // Проверяем, является ли текущая дата "более молодой" чем переданная
    if (month_ < date.month_ || (month_ == date.month_ && day_ < date.day_)) {
        age--;
    }

    return age;
}


std::string Date::toString() const noexcept {
    std::stringstream ss;
    // Записываем год, месяц и день в поток ss
    ss << year_ << "/" << month_ << "/" << day_;
    return ss.str();
}


bool Date::isLeapYear(int year) noexcept {
    if (year % 4 == 0) {
        if (year % 100) {
            return year % 400;
        }
        return true;
    }
    return false;
}

int Date::daysInMonth(int year, int month) noexcept {
    switch(month) {
        case 1: case 3: case 5: case 7: case 8: case 10: case 12: {
            return 31;
        }
        case 4: case 6: case 9: case 11: {
            return 30;
        }
        case 2: {
            return isLeapYear(year) ? 29 : 28;
        }
    }
}

Date Date::operator+(int days) const {
    int newYear = year_ + days / 365;
    int newMonth = month_ + (days % 365) / 30;
    int newDay = day_ + days % 30;
    return Date(newYear, newMonth, newDay);
}

Date Date::operator-(int days) const {
    int newYear = year_ - days / 365;
    int newMonth = month_ - (days % 365) / 30;
    int newDay = day_ - days % 30;
    return Date(newYear, newMonth, newDay);
}

std::ostream& operator<<(std::ostream& os, const Date& date) {
    os << date.toString();
    return os;
}

std::istream& operator>>(std::istream& in, Date& date) {
    in >> date.day_ >> date.month_ >> date.year_;
    return in;
}
bool Date::operator<(const Date& other) const {
    if (year_ < other.year_) return true;
    if (year_ > other.year_) return false;
    if (month_ < other.month_) return true;
    if (month_ > other.month_) return false;
    return day_ < other.day_;
}

bool Date::operator>(const Date& other) const {
    if (year_ > other.year_) return true;
    if (year_ < other.year_) return false;
    if (month_ > other.month_) return true;
    if (month_ < other.month_) return false;
    return day_ > other.day_;
}
bool Date::operator==(const Date& other) const {
    return year_ == other.year_ && month_ == other.month_ && day_ == other.day_;
}