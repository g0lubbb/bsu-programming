#pragma once

#ifndef DATE_H
#define DATE_H

#define _SILENCE_STDEXT_ARR_ITERS_DEPRECATION_WARNING
#include "lib/spdlog/include/spdlog/spdlog.h"
#include <iostream>
#include <tuple>
#include <cstdint>

class Date {
public:
    // TODO определить конструкторы и деструктор, один уже указан
    Date(int year, int month = 1, int day = 1) : year_(year) {
        if (month < 1 || month > 12) {
            throw std::invalid_argument("The date is incorrect");
        }
        int days_in_month = daysInMonth(year, month);
        if (day > days_in_month || day < 1) {
            throw std::invalid_argument("The date is incorrect");
        }

        month = month_;
        day_ = day;
    }
    Date(const Date& other)
            : year_(other.year_), month_(other.month_), day_(other.day_) {}
    ~Date();


    Date operator+(int days) const;
    Date operator-(int days) const;

// TODO перегрузить операторы сравнения
    bool operator<(const Date& other) const;
    bool operator>(const Date& other) const;
    bool operator==(const Date& other) const;
    int day() const noexcept {return day_;}
    int month() const noexcept {return month_;}
    int year() const noexcept {return year_;}
    int age() const noexcept; // возраст существа, на сегодня, если *this - дата отсчета
    int age(const Date& date) const noexcept; // возраст существа, на date, если *this - дата отсчета


    static bool isLeapYear(int year) noexcept ;
    static int daysInMonth(int year, int month) noexcept; //количество дней в месяце
    std::string toString() const noexcept;

private:
    int day_;
    int month_;
    int year_;

    //  std::shared_ptr<spdlog::logger> log_;

    friend std::ostream& operator<<(std::ostream& os, const Date& date);
    friend std::istream& operator>>(std::istream& is, Date& date);
};

#endif //DATE_H